<?php

namespace donateBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;

class DefaultController extends Controller
{
    public function indexAction()
    {
        return $this->render('donateBundle:Default:index.html.twig');
    }
}

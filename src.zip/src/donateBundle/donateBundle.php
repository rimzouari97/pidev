<?php

namespace donateBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class donateBundle extends Bundle
{
}

<?php

namespace giveBundle\Entity;

/**
 * material
 */
class material
{
    /**
     * @var int
     */
    private $id;

    /**
     * @var int
     */
    private $idAddress;

    /**
     * @var string
     */
    private $nameAddress;

    /**
     * @var string
     */
    private $address;

    /**
     * @var string
     */
    private $description;


    /**
     * Get id
     *
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set idAddress
     *
     * @param integer $idAddress
     *
     * @return material
     */
    public function setIdAddress($idAddress)
    {
        $this->idAddress = $idAddress;

        return $this;
    }

    /**
     * Get idAddress
     *
     * @return int
     */
    public function getIdAddress()
    {
        return $this->idAddress;
    }

    /**
     * Set nameAddress
     *
     * @param string $nameAddress
     *
     * @return material
     */
    public function setNameAddress($nameAddress)
    {
        $this->nameAddress = $nameAddress;

        return $this;
    }

    /**
     * Get nameAddress
     *
     * @return string
     */
    public function getNameAddress()
    {
        return $this->nameAddress;
    }

    /**
     * Set address
     *
     * @param string $address
     *
     * @return material
     */
    public function setAddress($address)
    {
        $this->address = $address;

        return $this;
    }

    /**
     * Get address
     *
     * @return string
     */
    public function getAddress()
    {
        return $this->address;
    }

    /**
     * Set description
     *
     * @param string $description
     *
     * @return material
     */
    public function setDescription($description)
    {
        $this->description = $description;

        return $this;
    }

    /**
     * Get description
     *
     * @return string
     */
    public function getDescription()
    {
        return $this->description;
    }
}


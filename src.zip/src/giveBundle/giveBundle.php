<?php

namespace giveBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class giveBundle extends Bundle
{
}
